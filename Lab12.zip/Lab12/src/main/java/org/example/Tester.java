package org.example;

public class Tester {
    private String name;
    private String surname;
    private int experienceInYears;
    private String englishLevel;
    private double salary;

    public Tester(String name, String surname, int experienceInYears, String englishLevel, double salary) {
        this.name = name;
        this.surname = surname;
        this.experienceInYears = experienceInYears;
        this.englishLevel = englishLevel;
        this.salary = salary;
    }

    public Tester(String name, String surname, int experienceInYears, double salary) {
        this(name, surname, experienceInYears, "Не знаю", salary);
    }

    public Tester(String name, String surname) {
        this(name, surname, 0, "Не знаю", 0.0);
    }

    public void printInfo() {
        System.out.println(name + " " + surname + " - " + experienceInYears + " лет опыта");
    }

    public void printInfo(boolean showSalary) {
        if (showSalary) {
            System.out.println(name + " " + surname + " - Зарплата: " + salary);
        } else {
            printInfo();
        }
    }

    public void printInfo(String additionalInfo) {
        System.out.println(name + " " + surname + " - " + additionalInfo);
    }

    public static void showTestersInfo() {
        System.out.println("Тест");
    }
}