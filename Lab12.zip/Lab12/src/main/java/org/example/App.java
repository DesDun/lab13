package org.example;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Hello, Даниил");

        Tester tester1 = new Tester("Даниил", "Толкач", 28, "Нормально", 10000);
        Tester tester2 = new Tester("Иван", "Степук", 0, 3000000);
        Tester tester3 = new Tester("Еще", "Кто-то");

        tester1.printInfo();
        tester2.printInfo(true);
        tester3.printInfo("Вот так вот");

        Tester.showTestersInfo();
    }
}
